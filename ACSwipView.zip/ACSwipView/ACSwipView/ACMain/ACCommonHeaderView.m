//
//  ACCommonHeaderView.m
//  ACSwipView
//
//  Created by AirChen on 2017/2/4.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import "ACCommonHeaderView.h"

@interface ACCommonHeaderView()

@property(nonatomic, strong) UIImageView *imageView;
@property(nonatomic, strong) UIScrollView *scrollView;

@end

@implementation ACCommonHeaderView

- (void)layoutSubviews
{
    
}

@end

@implementation ACHeaderItem

@end
