//
//  GoldHeader.h
//  ACSwipView
//
//  Created by AirChen on 2017/2/4.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#ifndef GoldHeader_h
#define GoldHeader_h


#endif /* GoldHeader_h */

#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth [UIScreen mainScreen].bounds.size.width
